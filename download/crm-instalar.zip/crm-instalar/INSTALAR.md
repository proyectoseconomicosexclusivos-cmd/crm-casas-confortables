# CRM Casas Confortables - Instalación

## Requisitos
- Node.js 18 o superior
- npm o bun

## Pasos de Instalación

### 1. Instalar dependencias
```bash
npm install
```

### 2. Generar Prisma
```bash
npx prisma generate
```

### 3. Iniciar en desarrollo
```bash
npm run dev
```

### 4. Para producción (ruta /crm)
```bash
NEXT_PUBLIC_BASE_PATH=/crm npm run build
NEXT_PUBLIC_BASE_PATH=/crm npm start
```

## Credenciales
- Email: admin@casasconfortables.com
- Contraseña: admin123

## Configuración Nginx
Añade esto a tu configuración de Nginx:

```nginx
location /crm {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_cache_bypass $http_upgrade;
}
```

## PM2 (recomendado para producción)
```bash
npm install -g pm2
pm2 start "npm start" --name crm
pm2 save
pm2 startup
```
